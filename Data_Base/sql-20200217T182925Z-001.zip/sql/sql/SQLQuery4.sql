--inserting to table
INSERT INTO EMPLOYEE VALUES('John', 'B' , 'Smith' , '123456789', '09-Jan-55', '731 Fondren, Houston, TX' , 'M' , 30000 ,'987654321', 5);
INSERT INTO EMPLOYEE VALUES('Franklin', 'T' , 'Wong' , '333445555', '08-Dec-45', '638 Voss, Houston, TX' , 'M' , 40000 ,'888665555', 5);
INSERT INTO EMPLOYEE VALUES('Joyce', 'A' , 'English' , '453453453', '31-Jul-62', '5631 Rice, Houston, TX' , 'f' , 25000 ,'333445555', 5);
INSERT INTO EMPLOYEE VALUES('Ramesh', 'K' , 'Narayan' , '666884444', '15-sep-52', '975 Fire Oak, Humble, TX' , 'M' , 38000 ,'333445555', 5);
INSERT INTO EMPLOYEE VALUES('James', 'E' , 'Borg' , '888665555', '10-Nov-27', '450 Stone, Houston, TX' , 'M' , 55000 ,null, 1);
INSERT INTO EMPLOYEE VALUES('Jennifer', 'S' , 'Wallace' , '987654321', '20-Jun-31', '291 Berry, Bellaire, TX' , 'F' , 43000 ,'888665555', 4);
INSERT INTO EMPLOYEE VALUES('Ahmad', 'V' , 'Jabber' , '987987987', '29-Mar-59', '980 Dallas, Houston, TX' , 'M' , 25000 ,'987654321', 4);
INSERT INTO EMPLOYEE VALUES('Alicia', 'J' , 'Zelaya' , '999887777', '19-Jul-58', '3321 Castle, SPring, TX' , 'F' , 25000 ,'987654321', 4);